#!/bin/bash

~/trinityrnaseq_r2013-02-25/Trinity.pl --seqType fq --JM 30G \
--left left.fastq -right right.fastq --full_cleanup --CPU 8